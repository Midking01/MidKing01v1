const _0x5892d7 = _0x33e1;
function _0x14e8() {
    const _0x41a09b = [
        'e\x20Cod3Uchi',
        'brctI',
        'ezone',
        'DD/MM/YYYY',
        'MODE',
        '\x0a▫️│▹\x20Time\x20',
        'fimWL',
        'LFsvi',
        'MaEhO',
        '\x0a▫️│▹\x20Comma',
        '2KqpZaG',
        'Etc/GMT',
        'EyDgW',
        '──▹\x0a\x0a',
        't\x0a▫️│▹By\x20Th',
        '\x0a╭────▫️│TK',
        'map',
        'ctions',
        'fs-extra',
        'ttps://git',
        '16480zJOEOl',
        '▹\x0a┴╭──────',
        'Iecda',
        '\x0a\x20\x0a︎╭──────',
        'zJaTG',
        'log',
        'push',
        'HH:mm:ss',
        'TKM\x20bot│▫️─',
        'length',
        'moment-tim',
        '9531gQpaLQ',
        '\x0a▫️|▹Keep\x20U',
        'zusRU',
        '──────────',
        'General',
        'IGOUz',
        '\x0a▫️│▹\x20Creat',
        '╭──────「\x20',
        '\x0a▫️│▹\x20Mode\x20',
        '2017134lIkHtr',
        'bot\x20COMMAN',
        'yes',
        'EoDVW',
        '───▹\x0a',
        '\x0a▫️│▹\x20Platf',
        'lejNO',
        'orm\x20:\x20',
        '───────▹\x0a',
        'format',
        'déveloper\x20',
        '\x0a▫️│▹\x20Ram\x20:',
        '115296VsaHDo',
        '\x0a╭────────',
        '2312216SFgEdv',
        'TwreU',
        'ork/mesfon',
        'freemem',
        '10004532atgYNk',
        '/../framew',
        '🥵🥵\x20Menu\x20er',
        'CleBN',
        'util',
        '\x0a▫️│▹\x20Date\x20',
        'nds\x20:\x20',
        '\x20TKM²\x0a▫️│▹\x20',
        '▹▫️┃TKM\x20bot',
        'M\x20bot│▫️───',
        '\x0a▫️│▹\x20Prefi',
        'sing\x0a▫️|\x0a▫️|',
        'd3Uchiha/T',
        'sKnjA',
        'ZzUhf',
        '\x0a▫️│▹TKM\x20bo',
        'hiha\x0a┬╰───',
        'User\x20:\x20',
        'menu2',
        'reur\x20',
        '───────™\x0a▫️',
        '──▹\x0a\x0a▫️TKM\x20',
        'OeDPr',
        'totalmem',
        'ork/zokou',
        'x\x20:\x20',
        'sendMessag',
        'eltahmd*,\x20',
        'toLocaleLo',
        '\x0a▫️│▹\x20',
        'PREFIXE',
        '22TNgUcD',
        'nomCom',
        'Beltah\x20Tec',
        'ork//zokou',
        'werCase',
        'KM-bot\x0a╰──',
        'OWNER_NAME',
        'categorie',
        'SVvme',
        'setDefault',
        'public',
        '/../set',
        'or:\x20Cod3Uc',
        'DS▫️\x0a',
        '316OIsRhg',
        '7ZdnkQu',
        'Je\x20suis\x20*B',
        'ha\x20\x0a╰─────',
        'platform',
        'private',
        'aSIDh',
        '┃▫️\x0a▫️|\x0a▫️|▹h',
        'HbvTt',
        'PVtZa',
        'SYfDb',
        '\x0a╰────────',
        '─────────▹',
        '2492835durPtz',
        'hub.com/Co',
        'Smczn',
        'match',
        '8070impslW',
        '─™\x0a╰────▫️│',
        '│▹\x20Theme\x20:'
    ];
    _0x14e8 = function () {
        return _0x41a09b;
    };
    return _0x14e8();
}
(function (_0x4845f0, _0x4ca518) {
    const _0x3144da = _0x33e1, _0x15e3da = _0x4845f0();
    while (!![]) {
        try {
            const _0x17d2b8 = parseInt(_0x3144da(0xf6)) / (-0x2042 + 0x1d * 0x96 + 0xf45) * (-parseInt(_0x3144da(0xcc)) / (0xdd4 + -0x10 + -0xdc2)) + -parseInt(_0x3144da(0xbb)) / (0x5c * 0x65 + -0x1 * 0x2637 + 0x1ee) + -parseInt(_0x3144da(0xae)) / (0x417 + -0x5 * 0x36c + 0xd09) * (parseInt(_0x3144da(0xd6)) / (-0x1bd7 * 0x1 + 0x1 * 0x4e + 0x1b8e)) + -parseInt(_0x3144da(0xea)) / (0x2 * 0xd06 + 0x8f3 + -0x22f9) + -parseInt(_0x3144da(0xaf)) / (-0x517 + 0x1f5b + -0x8bf * 0x3) * (parseInt(_0x3144da(0xf8)) / (0x1370 + 0x1 * 0x2447 + -0x37af)) + -parseInt(_0x3144da(0xe1)) / (0x1d3e + 0x2675 + -0x21d5 * 0x2) * (-parseInt(_0x3144da(0xbf)) / (-0x208c + 0x43 * 0x2f + 0x3 * 0x6c3)) + -parseInt(_0x3144da(0xa0)) / (0x434 + -0xb63 + 0x73a) * (-parseInt(_0x3144da(0xfc)) / (0xcaa + 0x4c5 + -0x1163));
            if (_0x17d2b8 === _0x4ca518)
                break;
            else
                _0x15e3da['push'](_0x15e3da['shift']());
        } catch (_0x5c6d41) {
            _0x15e3da['push'](_0x15e3da['shift']());
        }
    }
}(_0x14e8, 0x244c6 + 0x6a1b8 + 0x1a194));
const util = require(_0x5892d7(0x100)), fs = require(_0x5892d7(0xd4)), {zokou} = require(__dirname + (_0x5892d7(0xfd) + _0x5892d7(0x99))), {format} = require(__dirname + (_0x5892d7(0xfd) + _0x5892d7(0xfa) + _0x5892d7(0xd3))), os = require('os'), moment = require(_0x5892d7(0xe0) + _0x5892d7(0xc4)), s = require(__dirname + _0x5892d7(0xab));
function _0x33e1(_0x43856d, _0x4fc577) {
    const _0x31f294 = _0x14e8();
    return _0x33e1 = function (_0x2f9923, _0x15e94a) {
        _0x2f9923 = _0x2f9923 - (-0x2163 + -0x6 * -0x5d8 + -0x62 * 0x3);
        let _0x11a922 = _0x31f294[_0x2f9923];
        return _0x11a922;
    }, _0x33e1(_0x43856d, _0x4fc577);
}

zokou({
    'nomCom': _0x5892d7(0x93),
    'categorie': _0x5892d7(0xe5)
}, async (_0x599ad2, _0x38783e, _0x14ba45) => {
    const _0x1ebc3f = _0x5892d7, _0x34baf9 = {
            'PVtZa': function (_0x41409c, _0x58955a) {
                return _0x41409c(_0x58955a);
            },
            'MaEhO': function (_0xd0d909, _0x110701) {
                return _0xd0d909 + _0x110701;
            },
            'ZzUhf': _0x1ebc3f(0xfd) + _0x1ebc3f(0xa3),
            'SYfDb': _0x1ebc3f(0xaa),
            'LFsvi': function (_0x585ec8, _0x357cc9) {
                return _0x585ec8 != _0x357cc9;
            },
            'CleBN': _0x1ebc3f(0xec),
            'TwreU': _0x1ebc3f(0xb3),
            'OeDPr': _0x1ebc3f(0xcd),
            'Smczn': function (_0x3cd142) {
                return _0x3cd142();
            },
            'fimWL': _0x1ebc3f(0xdd),
            'SVvme': _0x1ebc3f(0xc5),
            'zJaTG': function (_0x2ebde2, _0x48c7a8) {
                return _0x2ebde2(_0x48c7a8);
            },
            'Iecda': function (_0x4e9f76, _0x5b56e6) {
                return _0x4e9f76 - _0x5b56e6;
            },
            'brctI': function (_0x267e69, _0x336877) {
                return _0x267e69 + _0x336877;
            },
            'aSIDh': _0x1ebc3f(0xb0) + _0x1ebc3f(0x9c) + _0x1ebc3f(0xf4) + _0x1ebc3f(0xa2) + 'h',
            'HbvTt': _0x1ebc3f(0xfe) + _0x1ebc3f(0x94),
            'lejNO': function (_0x18f7aa, _0xd6b45d) {
                return _0x18f7aa(_0xd6b45d);
            },
            'EyDgW': function (_0x26904c, _0x310386) {
                return _0x26904c + _0x310386;
            },
            'sKnjA': function (_0x5bae1d, _0x1e9e6d) {
                return _0x5bae1d + _0x1e9e6d;
            },
            'EoDVW': function (_0x514823, _0xb4a927) {
                return _0x514823 + _0xb4a927;
            },
            'zusRU': function (_0x767119, _0x2bf0a7) {
                return _0x767119(_0x2bf0a7);
            },
            'IGOUz': function (_0x274a5b, _0x286001) {
                return _0x274a5b(_0x286001);
            }
        };
    let {
            ms: _0x52d5c8,
            repondre: _0x592e96,
            prefixe: _0x3c0ea1,
            nomAuteurMessage: _0x1db70a,
            mybotpic: _0x560edf
        } = _0x14ba45, {cm: _0x1caf49} = _0x34baf9[_0x1ebc3f(0xb7)](require, _0x34baf9[_0x1ebc3f(0xca)](__dirname, _0x34baf9[_0x1ebc3f(0x8f)]));
    var _0x31e04f = {}, _0x1e5df7 = _0x34baf9[_0x1ebc3f(0xb8)];
    _0x34baf9[_0x1ebc3f(0xc9)](s[_0x1ebc3f(0xc6)][_0x1ebc3f(0x9d) + _0x1ebc3f(0xa4)](), _0x34baf9[_0x1ebc3f(0xff)]) && (_0x1e5df7 = _0x34baf9[_0x1ebc3f(0xf9)]);
    _0x1caf49[_0x1ebc3f(0xd2)](async (_0x2b4f01, _0x320aeb) => {
        const _0x1d09f7 = _0x1ebc3f;
        if (!_0x31e04f[_0x2b4f01[_0x1d09f7(0xa7)]])
            _0x31e04f[_0x2b4f01[_0x1d09f7(0xa7)]] = [];
        _0x31e04f[_0x2b4f01[_0x1d09f7(0xa7)]][_0x1d09f7(0xdc)](_0x2b4f01[_0x1d09f7(0xa1)]);
    }), moment['tz'][_0x1ebc3f(0xa9)](_0x34baf9[util[6].TZ]);
    const _0x1e9ff5 = _0x34baf9[_0x1ebc3f(0xbd)](moment)[_0x1ebc3f(0xf3)](_0x34baf9[_0x1ebc3f(0xc8)]), _0x1e4674 = _0x34baf9[_0x1ebc3f(0xbd)](moment)[_0x1ebc3f(0xf3)](_0x34baf9[_0x1ebc3f(0xa8)]);
    let _0x461081 = _0x1ebc3f(0xd1) + _0x1ebc3f(0x8a) + _0x1ebc3f(0xd7) + _0x1ebc3f(0x95) + _0x1ebc3f(0xc1) + _0x1ebc3f(0x88) + _0x1ebc3f(0x92) + s[_0x1ebc3f(0xa6)] + (_0x1ebc3f(0x8b) + _0x1ebc3f(0x9a)) + s[_0x1ebc3f(0x9f)] + (_0x1ebc3f(0xe9) + ':\x20') + _0x1e5df7 + (_0x1ebc3f(0xcb) + _0x1ebc3f(0x87)) + _0x1caf49[_0x1ebc3f(0xdf)] + (_0x1ebc3f(0x101) + ':\x20') + _0x1e4674 + (_0x1ebc3f(0xc7) + ':\x20') + _0x1e9ff5 + (_0x1ebc3f(0xf5) + '\x20') + _0x34baf9[_0x1ebc3f(0xda)](format, _0x34baf9[_0x1ebc3f(0xd8)](os[_0x1ebc3f(0x98)](), os[_0x1ebc3f(0xfb)]())) + '/' + _0x34baf9[_0x1ebc3f(0xda)](format, os[_0x1ebc3f(0x98)]()) + (_0x1ebc3f(0xef) + _0x1ebc3f(0xf1)) + os[_0x1ebc3f(0xb2)]() + (_0x1ebc3f(0xe7) + _0x1ebc3f(0xac) + _0x1ebc3f(0x91) + _0x1ebc3f(0xe4) + _0x1ebc3f(0xc0) + _0x1ebc3f(0xde) + _0x1ebc3f(0xcf)), _0x4aeb91 = _0x1ebc3f(0xf7) + _0x1ebc3f(0xba) + _0x1ebc3f(0x90) + _0x1ebc3f(0xd0) + _0x1ebc3f(0xc2) + _0x1ebc3f(0xb1) + _0x1ebc3f(0xe4) + _0x1ebc3f(0x96) + _0x1ebc3f(0xeb) + _0x1ebc3f(0xad);
    for (const _0x13f932 in _0x31e04f) {
        _0x4aeb91 += _0x1ebc3f(0xe8) + _0x13f932 + '\x20」';
        for (const _0x5ceac1 of _0x31e04f[_0x13f932]) {
            _0x4aeb91 += _0x1ebc3f(0x9e) + _0x5ceac1;
        }
        _0x4aeb91 += _0x1ebc3f(0xb9) + _0x1ebc3f(0xf2);
    }
    _0x4aeb91 += _0x1ebc3f(0xd9) + _0x1ebc3f(0xba) + _0x1ebc3f(0xe2) + _0x1ebc3f(0x8c) + _0x1ebc3f(0x89) + _0x1ebc3f(0xb5) + _0x1ebc3f(0xd5) + _0x1ebc3f(0xbc) + _0x1ebc3f(0x8d) + _0x1ebc3f(0xa5) + _0x1ebc3f(0xe4) + _0x1ebc3f(0xee);
    var _0x55ed0e = _0x34baf9[_0x1ebc3f(0xbd)](_0x560edf);
    if (_0x55ed0e[_0x1ebc3f(0xbe)](/\.(mp4|gif)$/i))
        try {
            _0x38783e[_0x1ebc3f(0x9b) + 'e'](_0x599ad2, {
                'video': { 'url': _0x55ed0e },
                'caption': _0x34baf9[_0x1ebc3f(0xc3)](_0x461081, _0x4aeb91),
                'footer': _0x34baf9[_0x1ebc3f(0xb4)],
                'gifPlayback': !![]
            }, { 'quoted': _0x52d5c8 });
        } catch (_0x12fe91) {
            console[_0x1ebc3f(0xdb)](_0x34baf9[_0x1ebc3f(0xc3)](_0x34baf9[_0x1ebc3f(0xb6)], _0x12fe91)), _0x34baf9[_0x1ebc3f(0xf0)](_0x592e96, _0x34baf9[_0x1ebc3f(0xce)](_0x34baf9[_0x1ebc3f(0xb6)], _0x12fe91));
        }
    else {
        if (_0x55ed0e[_0x1ebc3f(0xbe)](/\.(jpeg|png|jpg)$/i))
            try {
                _0x38783e[_0x1ebc3f(0x9b) + 'e'](_0x599ad2, {
                    'image': { 'url': _0x55ed0e },
                    'caption': _0x34baf9[_0x1ebc3f(0x8e)](_0x461081, _0x4aeb91),
                    'footer': _0x34baf9[_0x1ebc3f(0xb4)]
                }, { 'quoted': _0x52d5c8 });
            } catch (_0x45703f) {
                console[_0x1ebc3f(0xdb)](_0x34baf9[_0x1ebc3f(0xed)](_0x34baf9[_0x1ebc3f(0xb6)], _0x45703f)), _0x34baf9[_0x1ebc3f(0xe3)](_0x592e96, _0x34baf9[_0x1ebc3f(0xed)](_0x34baf9[_0x1ebc3f(0xb6)], _0x45703f));
            }
        else
            _0x34baf9[_0x1ebc3f(0xe6)](_0x592e96, _0x34baf9[_0x1ebc3f(0xca)](_0x461081, _0x4aeb91));
    }
});
