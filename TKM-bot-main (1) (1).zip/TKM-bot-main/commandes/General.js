const _0x380c56 = _0x29b2;
(function (_0x33c8b3, _0x567e0b) {
    const _0x48f239 = _0x29b2, _0x39d4fd = _0x33c8b3();
    while (!![]) {
        try {
            const _0x2b2076 = parseInt(_0x48f239(0x225)) / (0xb77 * 0x1 + -0x165 * 0x1 + -0xa11) * (parseInt(_0x48f239(0x218)) / (-0x2 * -0xde + 0x1 * 0x1151 + 0x145 * -0xf)) + -parseInt(_0x48f239(0x239)) / (-0x1 * -0xb23 + 0x16ac + -0x21cc) * (parseInt(_0x48f239(0x231)) / (-0x15fe * -0x1 + 0x1 * 0x1cad + -0x1 * 0x32a7)) + parseInt(_0x48f239(0x20a)) / (0x1dfd + -0x55c + -0x19 * 0xfc) * (-parseInt(_0x48f239(0x23d)) / (-0x32 * -0x86 + 0x2 * -0x1049 + -0x2 * -0x336)) + -parseInt(_0x48f239(0x1ff)) / (0x19ed + 0x820 + 0x5 * -0x6ce) * (parseInt(_0x48f239(0x257)) / (0x3ca + -0xec3 * -0x2 + 0x1aa * -0x14)) + parseInt(_0x48f239(0x1fb)) / (-0x5ea * -0x4 + -0x1793 + -0xc) * (parseInt(_0x48f239(0x20b)) / (0x1c26 + -0x2 * -0x313 + -0x2242)) + -parseInt(_0x48f239(0x1f3)) / (0x759 * 0x2 + -0x5 * 0xfc + -0x9bb) + parseInt(_0x48f239(0x255)) / (-0xa5d * -0x2 + 0x14e8 + -0x2996);
            if (_0x2b2076 === _0x567e0b)
                break;
            else
                _0x39d4fd['push'](_0x39d4fd['shift']());
        } catch (_0x3526a1) {
            _0x39d4fd['push'](_0x39d4fd['shift']());
        }
    }
}(_0x50a3, 0x1a2cac + 0x2 * -0xe4f9b + 0xb456 * 0x18));
const {zokou} = require(_0x380c56(0x1f7) + _0x380c56(0x203)), {getAllSudoNumbers, isSudoTableNotEmpty} = require(_0x380c56(0x21f) + 'o'), conf = require(_0x380c56(0x24f));
function _0x29b2(_0x59079a, _0x3bb313) {
    const _0x51f376 = _0x50a3();
    return _0x29b2 = function (_0xbf7f88, _0x3aaf0d) {
        _0xbf7f88 = _0xbf7f88 - (-0x1 * 0x211d + 0x5 * -0x1b7 + 0x2b8f);
        let _0x3a65f6 = _0x51f376[_0xbf7f88];
        return _0x3a65f6;
    }, _0x29b2(_0x59079a, _0x3bb313);
}
function _0x50a3() {
    const _0x50f27a = [
        'HELLO👋!,WE',
        'CaZdT',
        'concat',
        'uiZaP',
        'KM\x20bot\x20HEL',
        'xDfuu',
        'mods',
        '@s.whatsap',
        '2637755718',
        'reur\x20',
        'CQaeO',
        'LCOME\x20TO\x20T',
        'com/@Cod3U',
        'bPUYa',
        '\x20DEVELOPER',
        'IZkuy',
        's*\x20-----\x0a',
        '../set',
        'me\x20\x0a\x0a\x20⬡\x20Jo',
        '----------',
        'TEL;type=C',
        'nom',
        'cueJc',
        '23711688XsYGVe',
        '\x20:\x20https:/',
        '15176QNzSCM',
        'GhFVp',
        'other\x20sudo',
        'w.youtube.',
        'ned;\x0a',
        '9WtC0kuJqv',
        'chiha]\x20\x0a\x0a\x0a',
        'User*\x0a\x0a\x20*O',
        'FN:',
        'el\x20⬡\x20\x0a\x0a⬡⁠[',
        'atsapp.com',
        'match',
        'TAKUDZWA-T',
        'xkvAu',
        '🥵🥵\x20Menu\x20er',
        'OWNER_NAME',
        'SORVa',
        'link\x20error',
        'replace',
        'NG\x20TKM\x20bot',
        '\x20⬡\x0a\x0a❒⁠⁠⁠⁠[',
        'sTMLL',
        '5882393spnozE',
        'numero',
        'SbQvx',
        'OICE;waid=',
        '../framewo',
        'support',
        '-\x20💼\x20@',
        'ORG:undefi',
        '481941CIRntu',
        'https://ww',
        ',\x20Support\x20',
        'https://wh',
        '5327VIkVKU',
        'nSOfk',
        '/channel/0',
        'wWKgg',
        'rk/zokou',
        'wner\x20Numbe',
        'in\x20my\x20what',
        '𝚢\x20©\x20Cod3Uc',
        'emRuY',
        'YOUTUBE\x20LI',
        'BEGIN:VCAR',
        '122545uoCVEd',
        '200aIMpHF',
        'KTrlx',
        '-TKM',
        'NUMERO_OWN',
        '2637850281',
        'cTkEE',
        'General',
        'ELL;type=V',
        'log',
        'hiha-TKM',
        'zsctd',
        '029VaKjSra',
        '------\x0a⬡\x20',
        '18466kYGJWP',
        '⬡𝙿𝚘𝚠𝚎𝚛𝚎𝚍\x20𝚋',
        'XypBN',
        '*My\x20Super-',
        'yWwpB',
        'fywQn',
        'VERSION:3.',
        '../bdd/sud',
        'pEmjy',
        'FOR\x20CHOOSI',
        'ytLZb',
        'P\x20CENTER,A',
        'gQYmJ',
        '179kmlNlk',
        'THANK\x20YOU\x20',
        'etPuR',
        'sendMessag',
        'Cod3Uchiha',
        'vNKMV',
        'l0g]\x20⁠\x0a\x0a\x20⬡',
        'dev',
        'sapp\x20chann',
        'WPahc',
        'NK\x20IS\x20HERE',
        'P\x20FROM\x20THE',
        '7180ZgkkGD',
        'SK\x20FOR\x20HEL',
        'r\x0a*\x20:\x0a-\x20✨\x20',
        '\x0a\x0a------\x20*',
        '/wa.me/',
        'END:VCARD',
        'p.net',
        'OgCfr',
        '138jWdhnf',
        'KAnzM',
        ':\x0a\x0a',
        'DpcoZ',
        '414rULfmC'
    ];
    _0x50a3 = function () {
        return _0x50f27a;
    };
    return _0x50a3();
}
zokou({
    'nomCom': _0x380c56(0x244),
    'categorie': _0x380c56(0x211),
    'reaction': '💞'
}, async (_0x4aca16, _0xecf182, _0x1e1462) => {
    const _0x438eb9 = _0x380c56, _0x1acaa9 = {
            'nSOfk': function (_0xc583ba) {
                return _0xc583ba();
            },
            'KTrlx': function (_0x1de0aa, _0x5b6879) {
                return _0x1de0aa + _0x5b6879;
            },
            'DpcoZ': _0x438eb9(0x245) + _0x438eb9(0x237),
            'CaZdT': function (_0xbfdccb, _0x5b660c) {
                return _0xbfdccb + _0x5b660c;
            },
            'xkvAu': function (_0x467f91, _0x2b5cfa) {
                return _0x467f91 + _0x2b5cfa;
            },
            'uiZaP': function (_0x21fc94, _0x871aa8) {
                return _0x21fc94 + _0x871aa8;
            },
            'vNKMV': function (_0x20ff42, _0x1cc7e5) {
                return _0x20ff42 + _0x1cc7e5;
            },
            'emRuY': _0x438eb9(0x209) + 'D\x0a',
            'IZkuy': _0x438eb9(0x21e) + '0\x0a',
            'sTMLL': _0x438eb9(0x1e5),
            'WPahc': _0x438eb9(0x1fa) + _0x438eb9(0x1e1),
            'GhFVp': _0x438eb9(0x252) + _0x438eb9(0x212) + _0x438eb9(0x1f6),
            'SbQvx': _0x438eb9(0x236)
        }, {
            ms: _0x209c69,
            mybotpic: _0x1b2308
        } = _0x1e1462, _0x5127b9 = await _0x1acaa9[_0x438eb9(0x200)](isSudoTableNotEmpty);
    if (_0x5127b9) {
        let _0x1cd43d = _0x438eb9(0x21b) + _0x438eb9(0x1e4) + _0x438eb9(0x204) + _0x438eb9(0x233) + '@' + conf[_0x438eb9(0x20e) + 'ER'] + (_0x438eb9(0x234) + _0x438eb9(0x1df) + _0x438eb9(0x24e)), _0x115062 = await _0x1acaa9[_0x438eb9(0x200)](getAllSudoNumbers);
        for (const _0x3645f3 of _0x115062) {
            if (_0x3645f3)
                sudonumero = _0x3645f3[_0x438eb9(0x1ef)](/[^0-9]/g, ''), _0x1cd43d += _0x438eb9(0x1f9) + sudonumero + '\x0a';
            else
                return;
        }
        const _0xdabde3 = _0x1acaa9[_0x438eb9(0x20c)](conf[_0x438eb9(0x20e) + 'ER'][_0x438eb9(0x1ef)](/[^0-9]/g), _0x1acaa9[_0x438eb9(0x23c)]), _0x94c33c = _0x115062[_0x438eb9(0x240)]([_0xdabde3]);
        console[_0x438eb9(0x213)](_0x115062), console[_0x438eb9(0x213)](_0x94c33c), _0xecf182[_0x438eb9(0x228) + 'e'](_0x4aca16, {
            'image': { 'url': _0x1acaa9[_0x438eb9(0x200)](_0x1b2308) },
            'caption': _0x1cd43d,
            'mentions': _0x94c33c
        });
    } else {
        const _0x39f19a = _0x1acaa9[_0x438eb9(0x20c)](_0x1acaa9[_0x438eb9(0x23f)](_0x1acaa9[_0x438eb9(0x20c)](_0x1acaa9[_0x438eb9(0x1ea)](_0x1acaa9[_0x438eb9(0x23f)](_0x1acaa9[_0x438eb9(0x241)](_0x1acaa9[_0x438eb9(0x241)](_0x1acaa9[_0x438eb9(0x241)](_0x1acaa9[_0x438eb9(0x20c)](_0x1acaa9[_0x438eb9(0x1ea)](_0x1acaa9[_0x438eb9(0x22a)](_0x1acaa9[_0x438eb9(0x207)], _0x1acaa9[_0x438eb9(0x24d)]), _0x1acaa9[_0x438eb9(0x1f2)]), conf[_0x438eb9(0x1ec)]), '\x0a'), _0x1acaa9[_0x438eb9(0x22e)]), _0x1acaa9[_0x438eb9(0x258)]), conf[_0x438eb9(0x20e) + 'ER']), ':+'), conf[_0x438eb9(0x20e) + 'ER']), '\x0a'), _0x1acaa9[_0x438eb9(0x1f5)]);
        _0xecf182[_0x438eb9(0x228) + 'e'](_0x4aca16, {
            'contacts': {
                'displayName': conf[_0x438eb9(0x1ec)],
                'contacts': [{ 'vcard': _0x39f19a }]
            }
        }, { 'quoted': _0x209c69 });
    }
}), zokou({
    'nomCom': _0x380c56(0x22c),
    'categorie': _0x380c56(0x211),
    'reaction': '⛑️'
}, async (_0x3d9b3d, _0x3bc38a, _0x2490f7) => {
    const _0x4d310c = _0x380c56, _0x455388 = {
            'CQaeO': _0x4d310c(0x229) + _0x4d310c(0x20d),
            'cueJc': _0x4d310c(0x246) + '20',
            'yWwpB': _0x4d310c(0x1e9) + 'KM',
            'etPuR': _0x4d310c(0x20f) + '26',
            'xDfuu': _0x4d310c(0x23e) + _0x4d310c(0x249) + _0x4d310c(0x242) + _0x4d310c(0x223) + _0x4d310c(0x232) + _0x4d310c(0x230) + _0x4d310c(0x24c) + _0x4d310c(0x23b),
            'SORVa': function (_0x3f4fed) {
                return _0x3f4fed();
            },
            'pEmjy': function (_0x358284, _0x1a3560) {
                return _0x358284 + _0x1a3560;
            },
            'KAnzM': _0x4d310c(0x1eb) + _0x4d310c(0x247),
            'OgCfr': function (_0x2bba58, _0x2ef5e0) {
                return _0x2bba58(_0x2ef5e0);
            },
            'gQYmJ': function (_0xa1f0a7, _0x4b3d2e) {
                return _0xa1f0a7 + _0x4b3d2e;
            },
            'XypBN': function (_0x2d67c7, _0xcf2d07) {
                return _0x2d67c7 + _0xcf2d07;
            },
            'fywQn': function (_0x320492, _0x32828a) {
                return _0x320492 + _0x32828a;
            },
            'cTkEE': function (_0x44e184, _0x171194) {
                return _0x44e184(_0x171194);
            },
            'bPUYa': function (_0x2077ff, _0x4e4fcd) {
                return _0x2077ff(_0x4e4fcd);
            },
            'ytLZb': _0x4d310c(0x1ee)
        }, {
            ms: _0x23d6ec,
            mybotpic: _0x227c95
        } = _0x2490f7, _0x2a6f94 = [
            {
                'nom': _0x455388[_0x4d310c(0x248)],
                'numero': _0x455388[_0x4d310c(0x254)]
            },
            {
                'nom': _0x455388[_0x4d310c(0x21c)],
                'numero': _0x455388[_0x4d310c(0x227)]
            }
        ];
    let _0x1eab70 = _0x455388[_0x4d310c(0x243)];
    for (const _0x5d03bf of _0x2a6f94) {
        _0x1eab70 += _0x4d310c(0x251) + _0x4d310c(0x217) + _0x5d03bf[_0x4d310c(0x253)] + (_0x4d310c(0x256) + _0x4d310c(0x235)) + _0x5d03bf[_0x4d310c(0x1f4)] + '\x0a';
    }
    var _0x24b0c0 = _0x455388[_0x4d310c(0x1ed)](_0x227c95);
    if (_0x24b0c0[_0x4d310c(0x1e8)](/\.(mp4|gif)$/i))
        try {
            _0x3bc38a[_0x4d310c(0x228) + 'e'](_0x3d9b3d, {
                'video': { 'url': _0x24b0c0 },
                'caption': _0x1eab70
            }, { 'quoted': _0x23d6ec });
        } catch (_0x489f45) {
            console[_0x4d310c(0x213)](_0x455388[_0x4d310c(0x220)](_0x455388[_0x4d310c(0x23a)], _0x489f45)), _0x455388[_0x4d310c(0x238)](repondre, _0x455388[_0x4d310c(0x224)](_0x455388[_0x4d310c(0x23a)], _0x489f45));
        }
    else {
        if (_0x24b0c0[_0x4d310c(0x1e8)](/\.(jpeg|png|jpg)$/i))
            try {
                _0x3bc38a[_0x4d310c(0x228) + 'e'](_0x3d9b3d, {
                    'image': { 'url': _0x24b0c0 },
                    'caption': _0x1eab70
                }, { 'quoted': _0x23d6ec });
            } catch (_0x3e65d8) {
                console[_0x4d310c(0x213)](_0x455388[_0x4d310c(0x21a)](_0x455388[_0x4d310c(0x23a)], _0x3e65d8)), _0x455388[_0x4d310c(0x238)](repondre, _0x455388[_0x4d310c(0x21d)](_0x455388[_0x4d310c(0x23a)], _0x3e65d8));
            }
        else
            _0x455388[_0x4d310c(0x210)](repondre, _0x24b0c0), _0x455388[_0x4d310c(0x24b)](repondre, _0x455388[_0x4d310c(0x222)]);
    }
}), zokou({
    'nomCom': _0x380c56(0x1f8),
    'categorie': _0x380c56(0x211)
}, async (_0xe605a1, _0xaa54fe, _0x497fa1) => {
    const _0x2774f6 = _0x380c56, _0x5e3a6d = {
            'zsctd': function (_0x2d6449, _0x4c3405) {
                return _0x2d6449(_0x4c3405);
            },
            'wWKgg': _0x2774f6(0x226) + _0x2774f6(0x221) + _0x2774f6(0x1f0) + _0x2774f6(0x1fd) + _0x2774f6(0x250) + _0x2774f6(0x205) + _0x2774f6(0x22d) + _0x2774f6(0x1e6) + _0x2774f6(0x1fe) + _0x2774f6(0x1e7) + _0x2774f6(0x201) + _0x2774f6(0x216) + _0x2774f6(0x1e2) + _0x2774f6(0x22b) + _0x2774f6(0x208) + _0x2774f6(0x22f) + _0x2774f6(0x1f1) + _0x2774f6(0x1fc) + _0x2774f6(0x1e0) + _0x2774f6(0x24a) + _0x2774f6(0x1e3) + _0x2774f6(0x219) + _0x2774f6(0x206) + _0x2774f6(0x214)
        }, {
            ms: _0x3c9729,
            repondre: _0x165c3d,
            auteurMessage: _0x1bab24
        } = _0x497fa1;
    _0x5e3a6d[_0x2774f6(0x215)](_0x165c3d, _0x5e3a6d[_0x2774f6(0x202)]), await _0xaa54fe[_0x2774f6(0x228) + 'e'](_0x1bab24, { 'text': _0x2774f6(0x226) + _0x2774f6(0x221) + _0x2774f6(0x1f0) + _0x2774f6(0x1fd) + _0x2774f6(0x250) + _0x2774f6(0x205) + _0x2774f6(0x22d) + _0x2774f6(0x1e6) + _0x2774f6(0x1fe) + _0x2774f6(0x1e7) + _0x2774f6(0x201) + _0x2774f6(0x216) + _0x2774f6(0x1e2) + _0x2774f6(0x22b) + _0x2774f6(0x208) + _0x2774f6(0x22f) + _0x2774f6(0x1f1) + _0x2774f6(0x1fc) + _0x2774f6(0x1e0) + _0x2774f6(0x24a) + _0x2774f6(0x1e3) + _0x2774f6(0x219) + _0x2774f6(0x206) + _0x2774f6(0x214) }, { 'quoted': _0x3c9729 });
});
