<p align="center">
TKM bot v²
</p>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=DAA520&center=true&width=910&height=100&lines=THANKS FOR CHOOSING +MidKing01;MULTI+DEVICE+WHATSAPP+BOT" alt="Typing SVG" /></a>
  </p>

<p align="center">
  <a href="https://github.com/Cod3Uchiha">
    <img alt="TKM bot logo" height="200" src="https://telegra.ph/file/e07a3d933fb4cad0b3791.jpg">
  </a>
</p>

<p align="center">
  <a href="https://github.com/Cod3Uchiha?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Cod3Uchiha?label=Followers&style=social"></a>
  <a href="https://github.com/Cod3Uchiha/TKM-bot/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/Cod3Uchiha/TKM-bot?&style=social"></a>
  <a href="https://github.com/Cod3Uchiha/TKM-bot/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Cod3Uchiha/TKM-bot?style=social"></a>
  <a href="https://github.com/Cod3Uchiha/TKM-bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Cod3Uchiha/TKM-bot?label=Watching&style=social"></a>
</p>

 **Joshuamambo1md Deployment Methods**

•FORK THIS REPO
 <br>
 <a href='https://github.com/Cod3Uchiha/TKM-bot/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork-black?style=for-the-badge&logo=git&logoColor=white'/></a>

 GET SESSION ID HERE
 <br>
 <a href='https://tkmsession-929e14d27646.herokuapp.com/' target="_blank"><img alt='Get Session ID' src='https://img.shields.io/badge/Get session id-blue?style=for-the-badge&logo=opencv&logoColor=white'/></a> 

**DEPLOY ON HEROKU**

•If you don't have an account in Heroku, create one.
   <br>
    <a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>

•Now deploy.
    <br>
    <a href='https://dashboard.heroku.com/new?template=https://github.com/Cod3Uchiha/TKM-bot' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>

**DEPLOY ON RENDER**

•If you don't have an account in RENDER, create one and deploy.
    <br>
    <a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/></a>

**env for render**

_key_

```
DATABASE_URL
```
_value_

```
postgresql://tkm:Aqi6tqwyv5IwDHncTtVi5XtMGZvfndDJ@dpg-cqahogtds78s739sl81g-a.oregon-postgres.render.com/takudzwa
```
* [⭐️How to deploy on render⭐️](https://youtu.be/FiRpFMZZrMU?si=tyLUSRBqLt4wyfK-)


**DEPLOY ON REPLIT**

[not RECOMMENDED for now,don't even try it]

•Deploy.
    <br>
    <a href='https://replit.com/github/Cod3Uchiha/TKM-bot' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>

**•Koyeb and Render Deploy now available**

_Termux Setup not recommended_

**DEVELOPERS**

<table>
  <tr>
    <td>Danny</td>
    <td>Cod3Uchiha</td>
  </tr>
  <tr>
    <td><a href="https://github.com/DannyAkintunde"><img src="https://avatars.githubusercontent.com/u/142972494?v=4" width="180"</td>
    <td><a href="https://github.com/Cod3Uchiha"><img src="https://telegra.ph/file/7d1d362a15f946d427db1.jpg" width="180"</td>
  </tr>
</table>

**contributors**

```
Lazak28•fixed Heroku ban
```
```
Beltahmd•fixed sleeping problem
```

* [🧑‍💻 Follow The Cod3Uchiha whatsapp Channel🧑‍💻](https://chat.whatsapp.com/FCURRZJoRUd6Tuvf6DwUnZ)

